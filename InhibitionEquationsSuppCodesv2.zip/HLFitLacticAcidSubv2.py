# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 11:36:44 2017

@author: Tim
Lactate only growth
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from sklearn.metrics import r2_score
#import scipy.stats

#Constant glucose concentration (g/L)
G = 10.0
mu = 0.5

LAC = np.array([1.0, 3.0, 5.0, 8.0, 10.0, 12.0, 20.0, 40.0]) / 0.11206
#Lactate Concentration
L = (LAC / (1 + 10 ** (7 - 3.86)))
Lprmo = 12.0 / 0.11206
Lprime = Lprmo / (1 + 10 ** (7 - 3.86))
print(Lprime)

#Range of x-values for smooth plot
x = np.linspace(0.001, 0.3, 100)


def LGfunc1L(L, Kg, Kis): #Andrews and Noack
    growthRate = mu * (1 / (1 + (Kg / L) + (L / Kis)))
    return growthRate

def LGfunc2L(L, Kg, Kis): #Webb
    growthRate = mu * (L * (1 + Kg / Kis) / (Kg + L + L * L / Kis))
    return growthRate

def LGfunc3L(L, Kg, Kis): #Yano and co-workers
    growthRate = mu * (1 / (1 + Kg / L + (L / Kis) + (L / Kis) ** 2))
    return growthRate

def LGfunc4L(L, Kg, Kis): #Aiba and co-workers
    growthRate = mu * ((L / (Kg + L)) * np.exp(-L / Kis))
    return growthRate

def LGfunc5L(L, Kg, Kis): #Teissier-type
    growthRate = mu * (np.exp(-L / Kis) - np.exp(-L / Kg))
    return growthRate

def LGfunc6L(L, Kg, Kis, sig): #Webb with sigma
    growthRate = mu * ((L / (L + Kg * (1 + sig / Kis))) * np.exp(1.17 * sig * L))
    return growthRate

def LGfunc7L(L, Kg, Kis): #Wayman and Tseng
    if np.any(L) <= Lprime:
        growthRate = mu * (L / (Kg + L))
    else:
        growthRate = mu * ((L / (Kg + L)) - (Kis * (L - Lprime)))
    return growthRate

def Lfunc8L(L, Kl, alpha): #Aiba and co-workers
    #alpha = 4.6
    growthRate = mu * (L / (Kl + L)) * np.exp(-alpha*L)
    return growthRate

def Lfunc9L(L, Kl, Kis): #Jerusalimsky and Neronova
    growthRate = mu * (L / (Kl + L)) * (Kis/(Kis+L))
    return growthRate


#Growth rate data
ydata = np.array([0.32518, 0.36978, 0.38384, 0.38881, 0.3904, 0.39673, 0.32697, 0.21])

#Plot figures
#Andrews and Noack
plt.figure(1)
#Fit data
popt1L, pcov = curve_fit(LGfunc1L, L, ydata, p0 = [0.001, 0.000001])
y_pred1 = LGfunc1L(L, *popt1L)
R2_1 = r2_score(ydata, y_pred1)
plt.plot(x, LGfunc1L(x, *popt1L), 'g-', label = 'fit')
#Plot data
plt.plot(L, ydata, 'bo', label = 'data')
plt.errorbar(L, ydata, yerr = 0.004653, fmt=',', ecolor = 'r')
#err1U = LGfunc1L(x, popt1L[0] + pcov[0,0]**0.5, popt1L[1] + pcov[1,1]**0.5, popt1L[2] + pcov[2,2]**0.5)
#err1L = LGfunc1L(x, popt1L[0] - pcov[0,0]**0.5, popt1L[1] - pcov[1,1]**0.5, popt1L[2] - pcov[2,2]**0.5)
#plt.plot(x, err1U, 'y--')
#plt.plot(x, err1L, 'y--')
#plt.fill_between(x, err1U, err1L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth rate ($h^{-1}$)')
plt.legend()
plt.show()

#Webb
plt.figure(2)
#Fit data
popt2L, pcov = curve_fit(LGfunc2L, L, ydata, p0 = [0.0038, 0.2327])
y_pred2 = LGfunc2L(L, *popt2L)
R2_2 = r2_score(ydata, y_pred2)
plt.plot(x, LGfunc2L(x, *popt2L), 'g-', label = 'Fit')
#Plot Data
plt.plot(L, ydata, 'bo', label = 'data')
plt.errorbar(L, ydata, yerr = 0.004653, fmt=',', ecolor = 'r')
#err2U = LGfunc2L(x, popt2L[0] + pcov[0,0]**0.5, popt2L[1] - pcov[1,1]**0.5, popt2L[2] + pcov[2,2]**0.5, popt2L[3] - pcov[3,3]**0.5)
#err2L = LGfunc2L(x, popt2L[0] - pcov[0,0]**0.5, popt2L[1] + pcov[1,1]**0.5, popt2L[2] - pcov[2,2]**0.5, popt2L[3] + pcov[3,3]**0.5)
#plt.plot(x, err2U, 'y--')
#plt.plot(x, err2L, 'y--')
#plt.fill_between(x, err2U, err2L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth rate ($h^{-1}$)')
plt.legend()
plt.show()

#Yano and co-workers
plt.figure(3)
#Fit data
popt3L, pcov = curve_fit(LGfunc3L, L, ydata, p0 = [0.001, 0.00001])
y_pred3 = LGfunc3L(L, *popt3L)
R2_3 = r2_score(ydata, y_pred3)
plt.plot(x, LGfunc3L(x, *popt3L), 'g-', label = 'Fit')
#Plot Data
plt.plot(L, ydata, 'bo', label = 'data')
plt.errorbar(L, ydata, yerr = 0.004653, fmt=',', ecolor = 'r')
#err3U = LGfunc3L(x, popt3L[0] + pcov[0,0]**0.5, popt3L[1] + pcov[1,1]**0.5, popt3L[2] + pcov[2,2]**0.5)
#err3L = LGfunc3L(x, popt3L[0] - pcov[0,0]**0.5, popt3L[1] - pcov[1,1]**0.5, popt3L[2] - pcov[2,2]**0.5)
#plt.plot(x, err3U, 'y--')
#plt.plot(x, err3L, 'y--')
#plt.fill_between(x, err3U, err3L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth rate ($h^{-1}$)')
plt.legend()
plt.show()

#Aiba and co-workers
plt.figure(4)
#Fit data
popt4L, pcov = curve_fit(LGfunc4L, L, ydata, p0 = [0.01, 0.001])
y_pred4 = LGfunc4L(L, *popt4L)
R2_4 = r2_score(ydata, y_pred4)
plt.plot(x, LGfunc4L(x, *popt4L), 'g-', label = 'Fit')
#Plot Data
plt.plot(L, ydata, 'bo', label = 'data')
plt.errorbar(L, ydata, yerr = 0.004653, fmt=',', ecolor = 'r')
#err4U = LGfunc4L(x, popt4L[0] + pcov[0,0]**0.5, popt4L[1] + pcov[1,1]**0.5, popt4L[2] + pcov[2,2]**0.5)
#err4L = LGfunc4L(x, popt4L[0] - pcov[0,0]**0.5, popt4L[1] - pcov[1,1]**0.5, popt4L[2] - pcov[2,2]**0.5)
#plt.plot(x, err4U, 'y--')
#plt.plot(x, err4L, 'y--')
#plt.fill_between(x, err4U, err4L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth rate ($h^{-1}$)')
plt.legend()
plt.show()

#Tessier-type
plt.figure(5)
#Fit data
popt5L, pcov = curve_fit(LGfunc5L, L, ydata, p0 = [0.001, 0.001])
y_pred5 = LGfunc5L(L, *popt5L)
R2_5 = r2_score(ydata, y_pred5)
plt.plot(x, LGfunc5L(x, *popt5L), 'g-', label = 'Fit')
#Plot Data
plt.plot(L, ydata, 'bo', label = 'data')
plt.errorbar(L, ydata, yerr = 0.004653, fmt=',', ecolor = 'r')
#err5U = LGfunc5L(x, popt5L[0] + pcov[0,0]**0.5, popt5L[1] + pcov[1,1]**0.5, popt5L[2] + pcov[2,2]**0.5)
#err5L = LGfunc5L(x, popt5L[0] - pcov[0,0]**0.5, popt5L[1] - pcov[1,1]**0.5, popt5L[2] - pcov[2,2]**0.5)
#plt.plot(x, err5U, 'y--')
#plt.plot(x, err5L, 'y--')
#plt.fill_between(x, err5U, err5L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth rate ($h^{-1}$)')
plt.legend()
plt.show()

#Webb w/ sigma
plt.figure(6)
#Fit data
popt6L, pcov = curve_fit(LGfunc6L, L, ydata, p0 = (0.0001, 0.01, 0.1))
y_pred6 = LGfunc6L(L, *popt6L)
R2_6 = r2_score(ydata, y_pred6)
plt.plot(x, LGfunc6L(x, *popt6L), 'g-', label = 'Fit')
#Plot Data
plt.plot(L, ydata, 'bo', label = 'data')
plt.errorbar(L, ydata, yerr = 0.004653, fmt=',', ecolor = 'r')
#err6U = LGfunc6L(x, popt6L[0] + pcov[0,0]**0.5, popt6L[1] + pcov[1,1]**0.5, popt6L[2] + pcov[2,2]**0.5, popt6L[3] + math.fabs(pcov[3,3]**0.5))
#err6L = LGfunc6L(x, popt6L[0] - pcov[0,0]**0.5, popt6L[1] - pcov[1,1]**0.5, popt6L[2] - pcov[2,2]**0.5, popt6L[3] - math.fabs(pcov[3,3]**0.5))
#plt.plot(x, err6U, 'y--')
#plt.plot(x, err6L, 'y--')
#plt.fill_between(x, err6U, err6L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth rate ($h^{-1}$)')
plt.legend()
plt.show()

#Wayman and Tseng
plt.figure(7)
#Fit data
popt7L, pcov = curve_fit(LGfunc7L, L, ydata, p0 = [0.01, 0.001])
y_pred7 = LGfunc7L(L, *popt7L)
R2_7 = r2_score(ydata, y_pred7)
plt.plot(x, LGfunc7L(x, *popt7L), 'g-', label = 'Fit')
#Plot Data
plt.plot(L, ydata, 'bo', label = 'data')
plt.errorbar(L, ydata, yerr = 0.004653, fmt=',', ecolor = 'r')
#err7U = LGfunc7L(x, popt7L[0] + pcov[0,0]**0.5, popt7L[1] - pcov[1,1]**0.5, popt7L[2] - pcov[2,2]**0.5)
#err7L = LGfunc7L(x, popt7L[0] - pcov[0,0]**0.5, popt7L[1] + pcov[1,1]**0.5, popt7L[2] + pcov[2,2]**0.5)
#plt.plot(x, err7U, 'y--')
#plt.plot(x, err7L, 'y--')
#plt.fill_between(x, err7U, err7L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth rate ($h^{-1}$)')
plt.legend()
plt.show()

#Aiba and co-workers
plt.figure(8)
#Fit data
popt8L, pcov = curve_fit(Lfunc8L, L, ydata, p0 = (0.01, 0.01))
y_pred8 = Lfunc8L(L, *popt8L)
R2_8 = r2_score(ydata, y_pred8)
plt.plot(x, Lfunc8L(x, *popt8L), 'g-', label = 'fit')
#Plot data
plt.plot(L, ydata, 'bo', label = 'data')
plt.errorbar(L, ydata, yerr = 0.009921, fmt=',', ecolor = 'r')
#err8U = Lfunc8L(x, popt8L[0] + pcov[0,0]**0.5, popt8L[1] + pcov[1,1]**0.5, popt8L[2] + pcov[2,2]**0.5, popt8L[3] + pcov[3,3]**0.5)
#err8L = Lfunc8L(x, popt8L[0] - pcov[0,0]**0.5, popt8L[1] - pcov[1,1]**0.5, popt8L[2] - pcov[2,2]**0.5, popt8L[3] - pcov[3,3]**0.5)
#plt.plot(x, err8U, 'g--')
#plt.plot(x, err8L, 'g--')
#plt.fill_between(x, err8U, err8L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()

#Jerusalimsky and Neronova
plt.figure(9)
#Fit data
popt9L, pcov = curve_fit(Lfunc9L, L, ydata, p0 = (0.01, 0.01))
y_pred9 = Lfunc9L(L, *popt9L)
R2_9 = r2_score(ydata, y_pred9)
plt.plot(x, Lfunc9L(x, *popt9L), 'g-', label = 'fit')
#Plot data
plt.plot(L, ydata, 'bo', label = 'data')
plt.errorbar(L, ydata, yerr = 0.004653, fmt=',', ecolor = 'r')
#err8U = Lfunc8L(x, popt8L[0] + pcov[0,0]**0.5, popt8L[1] + pcov[1,1]**0.5, popt8L[2] + pcov[2,2]**0.5, popt8L[3] + pcov[3,3]**0.5)
#err8L = Lfunc8L(x, popt8L[0] - pcov[0,0]**0.5, popt8L[1] - pcov[1,1]**0.5, popt8L[2] - pcov[2,2]**0.5, popt8L[3] - pcov[3,3]**0.5)
#plt.plot(x, err8U, 'g--')
#plt.plot(x, err8L, 'g--')
#plt.fill_between(x, err8U, err8L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()

#Andrews and Noack
print('Andrews and Noack (Lactate substrate):')
print('Fit','Kg = ', popt1L[0], 'Kis = ', popt1L[1])
print('R^2:', R2_1)
#Webb
print('Webb (Lactate substrate):')
print('Fit','Kg = ', popt2L[0], 'Kis = ', popt2L[1])
print('R^2:', R2_2)
#Yano and co-workers
print('Yano and co-workers (Lactate substrate):')
print('Fit', 'Kg = ', popt3L[0], 'Kis = ', popt3L[1])
print('R^2:', R2_3)
#Aiba and co-workers
print('Aiba and co-workers (Lactate substrate):')
print('Fit', 'Kg = ', popt4L[0], 'Kis = ', popt4L[1])
print('R^2:', R2_4)
#Teissier-type
print('Teissier-type (Lactate substrate):')
print('Fit', 'Kg = ', popt5L[0], 'Kis = ', popt5L[1])
print('R^2:', R2_5)
#Webb w/sigma
print('Webb w/ sigma (Lactate substrate):')
print('Fit', 'Kg = ', popt6L[0], 'Kis = ', popt6L[1], 'sigma = ', popt6L[2])
print('R^2:', R2_6)
#Wayman and Tseng
print('Wayman and Tseng (Lactate substrate):')
print('Fit', 'Kg = ', popt7L[0], 'Kis = ', popt7L[1])
print('R^2:', R2_7)
#Made-up
print('Aiba and co-workers:')
print('Fit:', 'Kl = ', popt8L[0], 'alpha = ', popt8L[1])
print('R^2:', R2_8)
#Made-up
print('Jersualimsky and Neronova:')
print('Fit:', 'Kl = ', popt9L[0], 'Kis = ', popt9L[1])
print('R^2:', R2_9)
'''
chisq8 = scipy.stats.chisquare(ydata, Lfunc8L(L, *popt8L))
print('Chi Square 8:', chisq8)
chisq9 = scipy.stats.chisquare(ydata, Lfunc9L(L, *popt9L))
print('Chic Square 9:', chisq9)
'''