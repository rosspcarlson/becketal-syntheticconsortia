# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 11:51:32 2017

@author: Tim
Ecoli growth on only Acetate
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import scipy.stats
from sklearn.metrics import r2_score

#A' for Wayman and Tseng
Awtppp = 2.0 / 0.08203
Awtprime = Awtppp / (1 + (10 ** (7 - 4.76)))
print(Awtprime)
mu = 0.4
#Range of x-values for smooth plot
x = np.linspace(0.001, 1.5, 100)

#Acetate concentration (g/L)
A = np.array([0.1, 0.2, 0.5, 1.0, 2.5, 10.0, 20.0]) / 0.08203
Awt = A / (1 + (10 ** (7 - 4.76)))

#Growth Functions
def wtfunc1(Awt, Kg, Kis): #Andrews and Novack
    growthRate = mu * (1 / (1 + (Kg / Awt) + (Awt / Kis))) #Andrews and Noack
    return growthRate

def wtfunc2(Awt, Kg, Ks): #Webb
    growthRate = mu * (Awt * (1 + Kg / Ks) / (Kg + Awt + Awt * Awt / Ks)) #Webb
    return growthRate

def wtfunc3(Awt, Kg, Kis): #Yano and co-workers
    growthRate = mu * (1 / (1 + Kg / Awt + (Awt / Kis) + (Awt / Kis) ** 2))
    return growthRate

def wtfunc4(Awt, Kg, Kis): #Aiba and co-workers
    growthRate = mu * ((Awt / (Kg + Awt)) * np.exp(-Awt / Kis))
    return growthRate

def wtfunc5(Awt, Kg, Kis): #Teissier-type
    growthRate = mu * (np.exp(-Awt / Kis) - np.exp(-Awt / Kg))
    return growthRate

def wtfunc6(Awt, Kg, Kis, sig): #Webb with sigma
    growthRate = mu * (Awt / (Awt + Kg * (1 + sig / Kis))) * np.exp(1.17 * sig * Awt)
    return growthRate

def wtfunc7(Awt, Kg, Kis): #Wayman and Tseng
    if np.any(Awt) <= Awtprime:
        growthRate = mu * (Awt / (Kg + Awt))
    else:
        growthRate = mu * ((Awt / (Kg + Awt)) - (Kis * (Awt - Awtprime)))
    return growthRate

def wtfunc8(Awt, Ka, alpha): #Variation on Aiba and co-workers
    growthRate = (mu*(Awt/(Ka+Awt)))*np.exp(-alpha*Awt)
    return growthRate

def wtfunc9(Awt, Ka, Kis): #Jerusalimsky and Neronova
    growthRate = (mu*(Awt/(Ka+Awt)))*(Kis/(Kis+Awt))
    return growthRate

#Growth rate data (1/hr)
ywt = np.array([0.0416, 0.0541, 0.1081, 0.1936, 0.2293, 0.1478, 0.0537])

#Andrews and Noack
popt1, pcov = curve_fit(wtfunc1, Awt, ywt, p0 = [0.001, 0.01])
plt.plot(x, wtfunc1(x, *popt1), 'g-', label = 'fit')
y_pred1 = wtfunc1(Awt, *popt1)
R2_1 = r2_score(ywt, y_pred1)
#Plot data
plt.plot(Awt, ywt, 'bo', label = 'data')
plt.errorbar(Awt, ywt, yerr = 0.0098, fmt=',', ecolor = 'r')
#err1U = wtfunc1(x, popt1[0] + pcov[0,0]**0.5, popt1[1] - pcov[1,1]**0.5, popt1[2] + pcov[2,2]**0.5)
#err1L = wtfunc1(x, popt1[0] - pcov[0,0]**0.5, popt1[1] + pcov[1,1]**0.5, popt1[2] - pcov[2,2]**0.5)
#plt.plot(x, err1U, 'g--')
#plt.plot(x, err1L, 'g--')
#plt.fill_between(x, err1U, err1L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()

#Webb
plt.figure(2)
#Fit w/o bounds
popt2, pcov = curve_fit(wtfunc2, Awt, ywt, p0 = [0.01, 0.01])
plt.plot(x, wtfunc2(x, *popt2), 'g-', label = 'fit')
y_pred2 = wtfunc2(Awt, *popt2)
R2_2 = r2_score(ywt, y_pred2)
#Plot data
plt.plot(Awt, ywt, 'bo', label = 'data')
plt.errorbar(Awt, ywt, yerr = 0.0098, fmt=',', ecolor = 'r')
#err2U = wtfunc2(x, popt2[0] - pcov[0,0]**0.5, popt2[1] - pcov[1,1]**0.5, popt2[2] + pcov[2,2]**0.5)
#err2L = wtfunc2(x, popt2[0] + pcov[0,0]**0.5, popt2[1] + pcov[1,1]**0.5, popt2[2] + pcov[2,2]**0.5)
#plt.plot(x, err2U, 'g--')
#plt.plot(x, err2L, 'g--')
#plt.fill_between(x, err2U, err2L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()

#Yano and co-workers
plt.figure(3)
#Fit w/o bounds
popt3, pcov = curve_fit(wtfunc3, Awt, ywt, p0 = [0.01, 0.01])
plt.plot(x, wtfunc3(x, *popt3), 'g-', label = 'fit')
y_pred3 = wtfunc3(Awt, *popt3)
R2_3 = r2_score(ywt, y_pred3)
#Plot data
plt.plot(Awt, ywt, 'bo', label = 'data')
plt.errorbar(Awt, ywt, yerr = 0.0098, fmt=',', ecolor = 'r')
#err3U = wtfunc3(x, popt3[0] + pcov[0,0]**0.5, popt3[1] - pcov[1,1]**0.5, popt3[2] + pcov[2,2]**0.5)
#err3L = wtfunc3(x, popt3[0] - pcov[0,0]**0.5, popt3[1] + pcov[1,1]**0.5, popt3[2] - pcov[2,2]**0.5)
#plt.plot(x, err3U, 'g--')
#plt.plot(x, err3L, 'g--')
#plt.fill_between(x, err3U, err3L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()

#Aiba and co-workers
plt.figure(4)
#Fit w/o bounds
popt4, pcov = curve_fit(wtfunc4, Awt, ywt, p0 = [0.01, 0.01])
plt.plot(x, wtfunc4(x, *popt4), 'g-', label = 'fit')
y_pred4 = wtfunc4(Awt, *popt4)
R2_4 = r2_score(ywt, y_pred4)
#Plot data
plt.plot(Awt, ywt, 'bo', label = 'data')
plt.errorbar(Awt, ywt, yerr = 0.0098, fmt=',', ecolor = 'r')
#err4U = wtfunc4(x, popt4[0] + pcov[0,0]**0.5, popt4[1] - pcov[1,1]**0.5, popt4[2] + pcov[2,2]**0.5)
#err4L = wtfunc4(x, popt4[0] - pcov[0,0]**0.5, popt4[1] + pcov[1,1]**0.5, popt4[2] - pcov[2,2]**0.5)
#plt.plot(x, err4U, 'g--')
#plt.plot(x, err4L, 'g--')
#plt.fill_between(x, err4U, err4L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()

#Teissier-type
plt.figure(5)
#Fit w/o bounds
popt5, pcov = curve_fit(wtfunc5, Awt, ywt, p0 = [0.001, 0.01])
plt.plot(x, wtfunc5(x, *popt5), 'g-', label = 'fit')
y_pred5 = wtfunc5(Awt, *popt5)
R2_5 = r2_score(ywt, y_pred5)
#Plot data
plt.plot(Awt, ywt, 'bo', label = 'data')
plt.errorbar(Awt, ywt, yerr = 0.0098, fmt=',', ecolor = 'r')
#err5U = wtfunc5(x, popt5[0] + pcov[0,0]**0.5, popt5[1] - pcov[1,1]**0.5, popt5[2] + pcov[2,2]**0.5)
#err5L = wtfunc5(x, popt5[0] - pcov[0,0]**0.5, popt5[1] + pcov[1,1]**0.5, popt5[2] - pcov[2,2]**0.5)
#plt.plot(x, err5U, 'g--')
#plt.plot(x, err5L, 'g--')
#plt.fill_between(x, err5U, err5L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()

#Webb with sigma
plt.figure(6)
#Fit w/o bounds
popt6, pcov = curve_fit(wtfunc6, Awt, ywt, p0 = [0.01, 0.01, 0.01])
plt.plot(x, wtfunc6(x, *popt6), 'g-', label = 'fit')
y_pred6 = wtfunc6(Awt, *popt6)
R2_6 = r2_score(ywt, y_pred6)
#Plot data
plt.plot(Awt, ywt, 'bo', label = 'data')
plt.errorbar(Awt, ywt, yerr = 0.0098, fmt=',', ecolor = 'r')
#err6U = wtfunc6(x, popt6[0] + pcov[0,0]**0.5, popt6[1] + pcov[1,1]**0.5, popt6[2] + pcov[2,2]**0.5, popt6[3] + math.fabs(pcov[3,3]**0.5))
#err6L = wtfunc6(x, popt6[0] - pcov[0,0]**0.5, popt6[1] - pcov[1,1]**0.5, popt6[2] - pcov[2,2]**0.5, popt6[3] - math.fabs(pcov[3,3]**0.5))
#plt.plot(x, err6U, 'g--')
#plt.plot(x, err6L, 'g--')
#plt.fill_between(x, err6U, err6L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()

#Wayman and Tseng
plt.figure(7)
#Fit w/o bounds
popt7, pcov = curve_fit(wtfunc7, Awt, ywt, p0 = [0.01, 0.01])
plt.plot(x, wtfunc7(x, *popt7), 'g-', label = 'fit')
y_pred7 = wtfunc7(Awt, *popt7)
R2_7 = r2_score(ywt, y_pred7)
#Plot data
plt.plot(Awt, ywt, 'bo', label = 'data')
plt.errorbar(Awt, ywt, yerr = 0.0098, fmt=',', ecolor = 'r')
#err7U = wtfunc7(x, popt7[0] + pcov[0,0]**0.5, popt7[1] - pcov[1,1]**0.5, popt7[2] - pcov[2,2]**0.5)
#err7L = wtfunc7(x, popt7[0] - pcov[0,0]**0.5, popt7[1] + pcov[1,1]**0.5, popt7[2] + pcov[2,2]**0.5)
#plt.plot(x, err7U, 'g--')
#plt.plot(x, err7L, 'g--')
#plt.fill_between(x, err7U, err7L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()

#Variation on Aiba and co-workers
plt.figure(8)
#Fit w/o bounds
popt8, pcov = curve_fit(wtfunc8, Awt, ywt, p0 = [0.01, 0.01])
plt.plot(x, wtfunc8(x, *popt8), 'g-', label = 'fit')
y_pred8 = wtfunc8(Awt, *popt8)
R2_8 = r2_score(ywt, y_pred8)
#Plot data
plt.plot(Awt, ywt, 'bo', label = 'data')
plt.errorbar(Awt, ywt, yerr = 0.0098, fmt=',', ecolor = 'r')
#err8U = wtfunc8(x, popt8[0] + pcov[0,0]**0.5, popt8[1] - pcov[1,1]**0.5, popt8[2] + pcov[2,2]**0.5)
#err8L = wtfunc8(x, popt8[0] - pcov[0,0]**0.5, popt8[1] + pcov[1,1]**0.5, popt8[2] - pcov[2,2]**0.5)
#plt.plot(x, err8U, 'g--')
#plt.plot(x, err8L, 'g--')
#plt.fill_between(x, err8U, err8L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()

#Jerusalimsky and Neronova
plt.figure(9)
#Fit w/o bounds
popt9, pcov = curve_fit(wtfunc9, Awt, ywt, p0 = [0.01, 0.01])
plt.plot(x, wtfunc9(x, *popt9), 'g-', label = 'fit')
y_pred9 = wtfunc9(Awt, *popt9)
R2_9 = r2_score(ywt, y_pred9)
#Plot data
plt.plot(Awt, ywt, 'bo', label = 'data')
plt.errorbar(Awt, ywt, yerr = 0.0098, fmt=',', ecolor = 'r')
#err9U = wtfunc9(x, popt9[0] + pcov[0,0]**0.5, popt9[1] - pcov[1,1]**0.5, popt9[2] + pcov[2,2]**0.5)
#err9L = wtfunc9(x, popt9[0] - pcov[0,0]**0.5, popt9[1] + pcov[1,1]**0.5, popt9[2] - pcov[2,2]**0.5)
#plt.plot(x, err8U, 'g--')
#plt.plot(x, err8L, 'g--')
#plt.fill_between(x, err8U, err8L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()

#Andrews and Noack
print('Andrews and Noack')
print('Fit:', 'Kg = ', popt1[0], 'Kis = ', popt1[1])
print('R^2:', R2_1)
#Webb
print('Webb')
print('Fit:', 'Kg = ', popt2[0], 'Ks = ', popt2[1])
print('R^2:', R2_2)
#Yano and co-workers
print('Yano and co-workers')
print('Fit:', 'Kg = ', popt2[0], 'Kis = ', popt2[1])
print('R^2:', R2_3)
#Aiba and co-workers
print('Aiba and co-workers')
print('Fit:', 'Kg = ', popt4[0], 'Kis = ', popt4[1])
print('R^2:', R2_4)
#Teissier-type
print('Teissier-type')
print('Fit:','Kg = ', popt5[0], 'Kis = ', popt5[1])
print('R^2:', R2_5)
#Webb with sigma
print('Webb with sigma')
print('Fit:', 'Kg = ', popt6[0], 'Kis = ', popt6[1], 'sigma = ', popt6[2])
print('R^2:', R2_6)
#Wayman and Tseng
print('Wayman and Tseng')
print('Fit:','Kg = ', popt7[0], 'Kis = ', popt7[1])
print('R^2:', R2_7)
#Variation on Aiba and co-workers
print('Variation on Aiba and co-workers')
print('Fit:', 'Ka = ', popt8[0], 'alpha = ', popt8[1])
print('R^2:', R2_8)
#Jerusalimsky and Neronova
print('Jerusalimsky and Neronova')
print('Fit:', 'Ka = ', popt9[0], 'Kis = ', popt9[1])
print('R^2:', R2_9)

chisq1 = scipy.stats.chisquare(ywt, wtfunc1(Awt, *popt1))
chisq2 = scipy.stats.chisquare(ywt, wtfunc2(Awt, *popt2))
chisq3 = scipy.stats.chisquare(ywt, wtfunc3(Awt, *popt3))
chisq4 = scipy.stats.chisquare(ywt, wtfunc4(Awt, *popt4))
chisq5 = scipy.stats.chisquare(ywt, wtfunc5(Awt, *popt5))
chisq6 = scipy.stats.chisquare(ywt, wtfunc6(Awt, *popt6))
chisq7 = scipy.stats.chisquare(ywt, wtfunc7(Awt, *popt7))
chisq8 = scipy.stats.chisquare(ywt, wtfunc8(Awt, *popt8))
chisq9 = scipy.stats.chisquare(ywt, wtfunc9(Awt, *popt9))
print('Chi Square 1:', chisq1)
print('Chi Square 2:', chisq2)
print('Chi Square 3:', chisq3)
print('Chi Square 4:', chisq4)
print('Chi Square 5:', chisq5)
print('Chi Square 6:', chisq6)
print('Chi Square 7:', chisq7)
print('Chi Square 8:', chisq8)
print('Chi Square 9:', chisq9)