# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 11:29:47 2017

@author: Tim
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import scipy.stats
from sklearn.metrics import r2_score

#Constant glucose concentration (g/L)
G = 10.0 / 0.1806
#range of x-values for smooth plot
x = np.linspace(0.001, 0.4, 100)
mu = 0.65
muL = 0.5
Kg = 0.005

#Lactate concentration (g/L)
L = np.array([0.0, 1.0, 3.0, 4.0, 5.0, 7.0, 10.0, 20.0, 40.0]) / 0.11206
L0 = L / (1 + 10 ** (7 - 3.86))
#Lstart = 12.0 / 0.11206
#Lstar = Lstart / (1 + 10 ** (7 - 3.86))

#Growth functions
def Lfunc1(L0, Lstar): #Ghose and Tyagi
    growthRate = mu * ((1 - (L0 / Lstar)) * (G / (Kg + G)))
    return growthRate

def Lfunc2(L0, K): #Aiba and co-workers
    growthRate = mu * ((G / (Kg + G)) * np.exp(-K * L0))
    return growthRate

def Lfunc3(L0, Kis): #Jerusalimsky and Neronova
    growthRate = mu * ((G / (Kg + G)) * (Kis / (Kis + L0)))
    return growthRate

def Lfunc4(L0, Kl, alpha): #Variation on Aiba and co-workers
    growthRate = mu * ((G / (Kg + G)) + (L0 / (Kl + L0))) * np.exp(-alpha*L0)
    return growthRate

def Lfunc5(L0, Kl, Kis): #Variation on Jerusalimsky and Neronova
    growthRate = mu * ((G / (Kg + G)) + (L0 / (Kl + L0))) * (Kis / (Kis + L0))
    return growthRate

def Lfunc6(L0, K): #Dagley and Hinshelwood
    growthRate = mu * ((G / (Kg + G)) * (1 - K * L0))
    return growthRate

def Lfunc7(L0, K, Kis): #Holzberg and co-workers
    growthRate = mu - K * (L0 - Kis)
    return growthRate
    
#Growth rate data
ydata = np.array([0.68057, 0.70033, 0.73172, 0.71226, 0.73253, 0.73457, 0.71434, 0.59592, 0.37])

#Fitting figures
#Ghose and Tyagi
plt.figure(1)
#Fit data
popt1, pcov = curve_fit(Lfunc1, L0, ydata, p0 = (0.01))
y_pred1 = Lfunc1(L0, *popt1)
R2_1 = r2_score(ydata, y_pred1)
plt.plot(x, Lfunc1(x, *popt1), 'g-', label = 'fit')
#Plot data
plt.plot(L0, ydata, 'bo', label = 'data')
plt.errorbar(L0, ydata, yerr = 0.009921, fmt=',', ecolor = 'r')
#err1U = Lfunc1(x, popt1[0] + pcov[0,0]**0.5, popt1[1] + pcov[1,1]**0.5, popt1[2] + pcov[2,2]**0.5)
#err1L = Lfunc1(x, popt1[0] - pcov[0,0]**0.5, popt1[1] - pcov[1,1]**0.5, popt1[2] - pcov[2,2]**0.5)
#plt.plot(x, err1U, 'g--')
#plt.plot(x, err1L, 'g--')
#plt.fill_between(x, err1U, err1L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()

#Aiba and co-workers
plt.figure(2)
#Fit data
popt2, pcov = curve_fit(Lfunc2, L0, ydata, p0 = [0.001])
y_pred2 = Lfunc2(L0, *popt2)
R2_2 = r2_score(ydata, y_pred2)
plt.plot(x, Lfunc2(x, *popt2), 'g-', label = 'fit')
#Plot data
plt.plot(L0, ydata, 'bo', label = 'data')
plt.errorbar(L0, ydata, yerr = 0.009921, fmt=',', ecolor = 'r')
#err2U = Lfunc2(x, popt2[0] + pcov[0,0]**0.5, popt2[1] + pcov[1,1]**0.5, popt2[2] + pcov[2,2]**0.5)
#err2L = Lfunc2(x, popt2[0] - pcov[0,0]**0.5, popt2[1] - pcov[1,1]**0.5, popt2[2] - pcov[2,2]**0.5)
#plt.plot(x, err2U, 'g--')
#plt.plot(x, err2L, 'g--')
#plt.fill_between(x, err2U, err2L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()

#Jerusalimsky and Neronova
plt.figure(3)
#Fit data
popt3, pcov = curve_fit(Lfunc3, L0, ydata, p0 = (0.0001))
y_pred3 = Lfunc3(L0, *popt3)
R2_3 = r2_score(ydata, y_pred3)
plt.plot(x, Lfunc3(x, *popt3), 'g-', label = 'fit')
#Plot data
plt.plot(L0, ydata, 'bo', label = 'data')
plt.errorbar(L0, ydata, yerr = 0.009921, fmt=',', ecolor = 'r')
#err3U = Lfunc3(x, popt3[0] + pcov[0,0]**0.5, popt3[1] + pcov[1,1]**0.5, popt3[2] + pcov[2,2]**0.5)
#err3L = Lfunc3(x, popt3[0] - pcov[0,0]**0.5, popt3[1] - pcov[1,1]**0.5, popt3[2] - pcov[2,2]**0.5)
#plt.plot(x, err3U, 'g--')
#plt.plot(x, err3L, 'g--')
#plt.fill_between(x, err3U, err3L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()

#Variation on Aiba and co-workers
plt.figure(4)
#Fit data
popt4, pcov = curve_fit(Lfunc4, L0, ydata, p0 = (0.01, 0.01))
y_pred4 = Lfunc4(L0, *popt4)
R2_4 = r2_score(ydata, y_pred4)
plt.plot(x, Lfunc4(x, *popt4), 'g-', label = 'fit')
#Plot data
plt.plot(L0, ydata, 'bo', label = 'data')
plt.errorbar(L0, ydata, yerr = 0.009921, fmt=',', ecolor = 'r')
#err4U = Lfunc4(x, popt4[0] + pcov[0,0]**0.5, popt4[1] + pcov[1,1]**0.5, popt4[2] + pcov[2,2]**0.5, popt4[3] + pcov[3,3]**0.5)
#err4L = Lfunc4(x, popt4[0] - pcov[0,0]**0.5, popt4[1] - pcov[1,1]**0.5, popt4[2] - pcov[2,2]**0.5, popt4[3] - pcov[3,3]**0.5)
#plt.plot(x, err4U, 'g--')
#plt.plot(x, err4L, 'g--')
#plt.fill_between(x, err4U, err4L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()

#Variation on Jerusalimsky and Neronova
plt.figure(5)
#Fit data
popt5, pcov = curve_fit(Lfunc5, L0, ydata, p0 = (0.001, 0.0864))
y_pred5 = Lfunc5(L0, *popt5)
R2_5 = r2_score(ydata, y_pred5)
plt.plot(x, Lfunc5(x, *popt5), 'g-', label = 'fit')
#Plot data
plt.plot(L0, ydata, 'bo', label = 'data')
plt.errorbar(L0, ydata, yerr = 0.009921, fmt=',', ecolor = 'r')
#err5U = Lfunc5(x, popt5[0] + pcov[0,0]**0.5, popt5[1] + pcov[1,1]**0.5, popt5[2] + pcov[2,2]**0.5, popt5[3] + pcov[3,3]**0.5)
#err5L = Lfunc5(x, popt5[0] - pcov[0,0]**0.5, popt5[1] - pcov[1,1]**0.5, popt5[2] - pcov[2,2]**0.5, popt5[3] - pcov[3,3]**0.5)
#plt.plot(x, err5U, 'g--')
#plt.plot(x, err5L, 'g--')
#plt.fill_between(x, err5U, err5L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()

#Dagley and Hinshelwood
plt.figure(6)
#Fit data
popt6, pcov = curve_fit(Lfunc6, L0, ydata, p0 = (0.01))
y_pred6 = Lfunc6(L0, *popt6)
R2_6 = r2_score(ydata, y_pred6)
plt.plot(x, Lfunc6(x, *popt6), 'g-', label = 'fit')
#Plot data
plt.plot(L0, ydata, 'bo', label = 'data')
plt.errorbar(L0, ydata, yerr = 0.009921, fmt=',', ecolor = 'r')
#err6U = Lfunc6(x, popt6[0] + pcov[0,0]**0.5, popt6[1] + pcov[1,1]**0.5, popt6[2] + pcov[2,2]**0.5)
#err6L = Lfunc6(x, popt6[0] - pcov[0,0]**0.5, popt6[1] - pcov[1,1]**0.5, popt6[2] - pcov[2,2]**0.5)
#plt.plot(x, err6U, 'g--')
#plt.plot(x, err6L, 'g--')
#plt.fill_between(x, err6U, err6L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()

#Holzberg and co-workers
plt.figure(7)
#Fit data
popt7, pcov = curve_fit(Lfunc7, L0, ydata, p0 = (0.01, 0.01))
y_pred7 = Lfunc7(L0, *popt7)
R2_7 = r2_score(ydata, y_pred7)
plt.plot(x, Lfunc7(x, *popt7), 'g-', label = 'fit')
#Plot data
plt.plot(L0, ydata, 'bo', label = 'data')
plt.errorbar(L0, ydata, yerr = 0.009921, fmt=',', ecolor = 'r')
#err7U = Lfunc1(x, popt7[0] + pcov[0,0]**0.5, popt7[1] + pcov[1,1]**0.5, popt7[2] + pcov[2,2]**0.5)
#err7L = Lfunc1(x, popt7[0] - pcov[0,0]**0.5, popt7[1] - pcov[1,1]**0.5, popt7[2] - pcov[2,2]**0.5)
#plt.plot(x, err7U, 'g--')
#plt.plot(x, err7L, 'g--')
#plt.fill_between(x, err7U, err7L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()


#Ghose and Tyagi
print('Ghose and Tyagi:')
print('Fit:', 'L* = ', popt1[0])
print('R^2:', R2_1)
#Aiba and co-workers
print('Aiba and co-workers:')
print('Fit:', 'K = ', popt2[0])
print('R^2:', R2_2)
#Jerusalimsky and Neronova
print('Jerusalimsky and Neronova:')
print('Fit:', 'Kis = ', popt3[0])
print('R^2:', R2_3)
#Made-up
print('Variation on Aiba and co-workers:')
print('Fit:', 'Kl = ', popt4[0], 'alpha = ', popt4[1])
print('R^2:', R2_4)
#Made-up Variant
print('Variation on Jerusalimsky and Neronova:')
print('Fit:', 'Kl = ', popt5[0], 'Kis = ', popt5[1])
print('R^2:', R2_5)
#Dagley and Hinshelwood
print('Dagley and Hinklewood:')
print('Fit:', 'K = ', popt6[0])
print('R^2:', R2_6)
#Holzberg and co-workers
print('Jerusalimsky and Neronova:')
print('Fit:', 'K = ', popt7[0], 'Kis = ', popt7[1])
print('R^2:', R2_7)

chisq1 = scipy.stats.chisquare(ydata, Lfunc1(L0, *popt1))
chisq2 = scipy.stats.chisquare(ydata, Lfunc2(L0, *popt2))
chisq3 = scipy.stats.chisquare(ydata, Lfunc3(L0, *popt3))
chisq4 = scipy.stats.chisquare(ydata, Lfunc4(L0, *popt4))
chisq5 = scipy.stats.chisquare(ydata, Lfunc5(L0, *popt5))
print('Chi Square 1:', chisq1)
print('Chi Square 2:', chisq2)
print('Chi Square 3:', chisq3)
print('Chi Square 4:', chisq4)
print('Chi Square 5:', chisq5)

'''
dof1 = len(L0) - len(popt1)
dof2 = len(L0) - len(popt2)
dof3 = len(L0) - len(popt3)
dof4 = len(L0) - len(popt4)
dof5 = len(L0) - len(popt5)
print(dof1)
print(dof2)
print(dof3)
print(dof4)
print(dof5)
'''