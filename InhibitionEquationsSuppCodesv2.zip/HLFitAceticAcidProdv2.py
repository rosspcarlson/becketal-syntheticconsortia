# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 11:47:08 2017

@author: Tim
Ecoli growth with Acetate and Glucose as substrates
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from sklearn.metrics import r2_score
#import scipy.stats

#Constant glucose concentration (g/L)
G = 10.0 / 0.1806
mu = 0.65
muA = 0.4
Kg = 0.005


A = np.array([0.1, 0.2, 0.5, 1.0, 2.5, 10.0, 20.0]) / 0.08203
#Acetate concentration (g/L)
Awt = A / (1 + 10 ** (7 - 4.76))
Astar = 12.0 / 0.08203
Awtstar = Astar / (1 + 10 ** (7 - 4.76))
print(Awt)
print(Awtstar)
#rage of x-values for smooth plot
x = np.linspace(0.0001, 1.5, 100)

#Growth Functions

def wt0func1(Awt, K): #Dagley and Hinshelwood
    growthRate = mu * ((G / (Kg + G)) * (1 - K * Awt))
    return growthRate

def wt0func2(Awt, K, Kis): #Holzberg and co-workers
    growthRate = mu - K * (Awt - Kis)
    return growthRate

def wt0func3(Awt, Awtstar): #Ghose and Tyagi
    growthRate = mu * ((1 - (Awt / Awtstar)) * (G / (Kg + G)))
    return growthRate

def wt0func4(Awt, K): #Aiba and co-workers
    growthRate = mu * ((G / (Kg + G)) * np.exp(-K * Awt))
    return growthRate

def wt0func5(Awt, Kis): #Jerusalimsky and Neronova
    growthRate = mu * ((G / (Kg + G)) * (Kis / (Kis + Awt)))
    return growthRate

def wt0func6(Awt, Ka, alpha): #Variation 1 on Aiba and co-workers
    growthRate = (mu*(G/(Kg+G))+muA*(Awt/(Ka+Awt)))*np.exp(-alpha*Awt)
    return growthRate

def wt0func7(Awt, Ka, alpha): #Variation 2 on Aiba and co-workers
    growthRate = (mu*((G/(Kg+G))+(Awt/(Ka+Awt))))*np.exp(-alpha*Awt)
    return growthRate

def wt0func8(Awt, Ka, Kis): #Variation 1 on Jerusalimsky and Neronova
    growthRate = (mu*(G/(Kg+G))+muA*(Awt/(Ka+Awt)))*(Kis/(Kis+Awt))
    return growthRate

def wt0func9(Awt, Ka, Kis): #Variation 2 on Jerusalimsky and Neronova
    growthRate = (mu*((G/(Kg+G))+(Awt/(Ka+Awt))))*(Kis/(Kis+Awt))
    return growthRate

#Growth rate data (1/hr)
ywt = np.array([0.6515, 0.6475, 0.6048, 0.6036, 0.4933, 0.2997, 0.0478])


#Dagley and Hinshelwood
plt.figure(1)
#Curve fitting
popt1, pcov = curve_fit(wt0func1, Awt, ywt, p0 = [0.5])
y_pred1 = wt0func1(Awt, *popt1)
R2_1 = r2_score(ywt, y_pred1)
plt.plot(x, wt0func1(x, *popt1), 'g-', label = 'fit')
#Plot data
plt.plot(Awt, ywt, 'bo', label = 'data')
plt.errorbar(Awt, ywt, yerr = 0.0256, fmt=',', ecolor = 'r')
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()

#Holzberg and co-workers
plt.figure(2)
#Curve fitting
popt2, pcov = curve_fit(wt0func2, Awt, ywt, p0 = [0.5, 0.5])
y_pred2 = wt0func2(Awt, *popt2)
R2_2 = r2_score(ywt, y_pred2)
plt.plot(x, wt0func2(x, *popt2), 'g-', label = 'fit')
#Plot data
plt.plot(Awt, ywt, 'bo', label = 'data')
plt.errorbar(Awt, ywt, yerr = 0.0256, fmt=',', ecolor = 'r')
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()


#Ghose and Tyagi
plt.figure(3)
#Curve fitting
popt3, pcov = curve_fit(wt0func3, Awt, ywt, p0 = [0.01])
y_pred3 = wt0func3(Awt, *popt3)
R2_3 = r2_score(ywt, y_pred3)
plt.plot(x, wt0func3(x, *popt3), 'g-', label = 'fit')
#Plot data
plt.plot(Awt, ywt, 'bo', label = 'data')
plt.errorbar(Awt, ywt, yerr = 0.0256, fmt=',', ecolor = 'r')
#err3U = wt0func3(x, popt3[0] + pcov[0,0]**0.5, popt3[1] + pcov[1,1]**0.5, popt3[2] + pcov[2,2]**0.5)
#err3L = wt0func3(x, popt3[0] - pcov[0,0]**0.5, popt3[1] - pcov[1,1]**0.5, popt3[2] - pcov[2,2]**0.5)
#plt.plot(x, err3U, 'g--')
#plt.plot(x, err3L, 'g--')
#plt.fill_between(x, err3U, err3L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()


#Aiba and co-workers
plt.figure(4)
#Curve fitting
popt4, pcov = curve_fit(wt0func4, Awt, ywt, p0 =[0.1])
y_pred4 = wt0func4(Awt, *popt4)
R2_4 = r2_score(ywt, y_pred4)
plt.plot(x, wt0func4(x, *popt4), 'g-', label = 'fit')
#Plot data
plt.plot(Awt, ywt, 'bo', label = 'data')
plt.errorbar(Awt, ywt, yerr = 0.0256, fmt=',', ecolor = 'r')
#err4U = wt0func3(x, popt4[0] + pcov[0,0]**0.5, popt4[1] + pcov[1,1]**0.5, popt4[2] + pcov[2,2]**0.5)
#err4L = wt0func3(x, popt4[0] - pcov[0,0]**0.5, popt4[1] - pcov[1,1]**0.5, popt4[2] - pcov[2,2]**0.5)
#plt.plot(x, err4U, 'g--')
#plt.plot(x, err4L, 'g--')
#plt.fill_between(x, err4U, err4L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()


#Jerusalimsky and Neronova
plt.figure(5)
#Curve fitting
popt5, pcov = curve_fit(wt0func5, Awt, ywt, p0 = [0.05])
y_pred5 = wt0func5(Awt, *popt5)
R2_5 = r2_score(ywt, y_pred5)
plt.plot(x, wt0func5(x, *popt5), 'g-', label = 'fit')
#Plot data
plt.plot(Awt, ywt, 'bo', label = 'data')
plt.errorbar(Awt, ywt, yerr = 0.0256, fmt=',', ecolor='r')
#err5U = wt0func5(x, popt5[0] + pcov[0,0]**0.5, popt5[1] + pcov[1,1]**0.5, popt5[2] + pcov[2,2]**0.5)
#err5L = wt0func5(x, popt5[0] - pcov[0,0]**0.5, popt5[1] - pcov[1,1]**0.5, popt5[2] - pcov[2,2]**0.5)
#plt.plot(x, err5U, 'g--')
#plt.plot(x, err5L, 'g--')
#plt.fill_between(x, err5U, err5L, facecolor = "gray", alpha = 0.15)
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()

#Made Up
plt.figure(6)
#Curve fitting
popt8, pcov = curve_fit(wt0func6, Awt, ywt, p0 = [0.01, 0.01])
y_pred8 = wt0func6(Awt, *popt8)
R2_8 = r2_score(ywt, y_pred8)
plt.plot(x, wt0func6(x, *popt8), 'g-', label = 'fit')
#Plot data
plt.plot(Awt, ywt, 'bo', label = 'data')
plt.errorbar(Awt, ywt, yerr = 0.0256, fmt=',', ecolor='r')
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()

#Made Up Single mu max
plt.figure(7)
#Curve fitting
popt9, pcov = curve_fit(wt0func7, Awt, ywt, p0 = [0.01, 0.01])
y_pred9 = wt0func7(Awt, *popt9)
R2_9 = r2_score(ywt, y_pred9)
plt.plot(x, wt0func7(x, *popt9), 'g-', label = 'fit')
#Plot data
plt.plot(Awt, ywt, 'bo', label = 'data')
plt.errorbar(Awt, ywt, yerr = 0.0256, fmt=',', ecolor='r')
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()

#Made Up Variant
plt.figure(8)
#Curve fitting
popt10, pcov = curve_fit(wt0func8, Awt, ywt, p0 = [0.01, 0.01])
y_pred10 = wt0func8(Awt, *popt10)
R2_10 = r2_score(ywt, y_pred10)
plt.plot(x, wt0func8(x, *popt10), 'g-', label = 'fit')
#Plot data
plt.plot(Awt, ywt, 'bo', label = 'data')
plt.errorbar(Awt, ywt, yerr = 0.0256, fmt=',', ecolor='r')
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()

#Made Up Variant Single mu max
plt.figure(9)
#Curve fitting
popt11, pcov = curve_fit(wt0func9, Awt, ywt, p0 = [0.01, 0.01])
y_pred11 = wt0func9(Awt, *popt11)
R2_11 = r2_score(ywt, y_pred11)
plt.plot(x, wt0func9(x, *popt11), 'g-', label = 'fit')
#Plot data
plt.plot(Awt, ywt, 'bo', label = 'data')
plt.errorbar(Awt, ywt, yerr = 0.0256, fmt=',', ecolor='r')
plt.xlabel('Protonated Organic Acid (mM)')
plt.ylabel('Growth Rate ($h^{-1}$)')
plt.legend()
plt.show()




#Dagley and Hinshelwood
print('Dagley and Hinshelwood')
print('Fit:', 'K = ', popt1[0])
print('R^2:', R2_1)
#Holzber and co-workers
print('Holzberg and co-workers')
print('Fit:', 'K = ', popt2[0], 'Kis = ', popt2[1])
print('R^2:', R2_2)

#Ghose and Tyagi
print('Ghose and Tyagi')
print('Fit:', 'A*= ', popt3[0])
print('R^2:', R2_3)
#Aiba and co-workers
print('Aiba and co-workers')
print('Fit:', 'K = ', popt4[0])
print('R^2:', R2_4)
#Jerusalimsky and Neronova
print('Jerusalimsky and Neronova')
print('Fit:', 'Kis = ', popt5[0])
print('R^2:', R2_5)

#Variation 1 on Aiba and co-workers
print('Variation 1 on Aiba and co-workers')
print('Fit:', 'Ka = ', popt8[0], 'alpha = ', popt8[1])
print('R^2:', R2_8)
#Variation 2 on Aiba and co-workers
print('Made Up single mu max')
print('Fit:', 'Ka = ', popt9[0], 'alpha = ', popt9[1])
print('R^2:', R2_9)
#Variation 1 on Jerusalimsky and Neronova
print('Variation 1 on Jersualimsky and Neronova')
print('Fit:','Ka = ', popt10[0], 'Kis = ', popt10[1])
print('R^2:', R2_10)
#Variation 2 on Jerusalimsky and Neronova
print('Variation 2 on Jersualimsky and Neronova')
print('Fit:', 'Ka = ', popt11[0], 'Kis = ', popt11[1])
print('R^2:', R2_11)
'''
chisq3 = scipy.stats.chisquare(ywt, wt0func3(Awt, *popt3))
chisq4 = scipy.stats.chisquare(ywt, wt0func4(Awt, *popt4))
chisq5 = scipy.stats.chisquare(ywt, wt0func5(Awt, *popt5))
chisq8 = scipy.stats.chisquare(ywt, wt0func8(Awt, *popt8))
chisq9 = scipy.stats.chisquare(ywt, wt0func9(Awt, *popt9))
chisq10 = scipy.stats.chisquare(ywt, wt0func10(Awt, *popt10))
chisq11 = scipy.stats.chisquare(ywt, wt0func11(Awt, *popt11))
print('Chi Square 3:', chisq3)
print('Chi Square 4:', chisq4)
print('Chi Square 5:', chisq5)
print('Chi Square 8:', chisq8)
print('Chi Square 9:', chisq9)
print('Chi Square 10:', chisq10)
print('Chi Square 11:', chisq11)
'''